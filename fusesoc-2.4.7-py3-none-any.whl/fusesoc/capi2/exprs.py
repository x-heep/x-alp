# Copyright FuseSoC contributors
# Licensed under the 2-Clause BSD License, see LICENSE for details.
# SPDX-License-Identifier: BSD-2-Clause

r"""Support for parsing String expression syntax in core files

FuseSoC core files allow strings matching the following pseudo-BNF:

  exprs ::= expr
          | expr exprs

  expr ::= word
         | conditional

  word ::= [a-zA-Z0-9:<>.\[\]_-,=~/^+"]+    (one or more alphanum/special chars)

  conditional ::= condition "?" "(" exprs ")"

  condition ::= "!" word
              | word


A condition of the form "foo ? (bar)" is interpreted as 'if the "foo" flag is
set, then "bar", otherwise nothing'. Similarly, "!foo ? (bar)" is interpreted
as 'if the "foo" flag is not set then "bar", otherwise nothing'.

Expanding some exprs with a set of flags results in a space-separated string
containing each word that matched.

"""

from functools import lru_cache
from typing import Any, Sequence

from pydantic import GetCoreSchemaHandler, validate_call
from pydantic_core import CoreSchema, core_schema
from pyparsing import (
    Forward,
    Group,
    OneOrMore,
    Optional,
    ParseException,
    ParseResults,
    Suppress,
    Word,
    alphanums,
)

from .flags import FlagDefs


def _cond_parse_action(tokens: ParseResults):
    """A parse action for conditional terms"""
    # A conditional term (see _make_cond_parser) has 2 or 3 tokens, depending
    # on whether it was negated or not.
    assert len(tokens) in [2, 3]

    return (
        (True, tokens[1], tokens[2])
        if len(tokens) == 3
        else (False, tokens[0], tokens[1])
    )


_PARSER = None


def _get_parser() -> Forward:
    """Return a pyparsing parser for the exprs syntax

    This returns a basic "AST" that consists of a list of "exprs". Each expr is
    represented by either a string (if it's just a word) or a tuple of the form
    (negated, flag, exprs).

    Here, negated is a boolean which is true if the condition should be
    negated. flag is a word giving the flag to match for the condition. exprs
    is the AST for the list of exprs inside the parentheses.

    To avoid creating the parser repeatedly, this function is memoized.

    """
    global _PARSER
    if _PARSER is not None:
        return _PARSER

    word = Word(alphanums + '`:<>.[]_-,=~/^+"$')
    exprs = Forward()

    conditional = (
        Optional("!")
        + word
        + Suppress("?")
        + Suppress("(")
        + Group(exprs)
        + Suppress(")")
    )
    exprs <<= OneOrMore(conditional ^ word)
    conditional.set_parse_action(_cond_parse_action)
    _PARSER = exprs
    return _PARSER


SimplifiedAst = list[str | tuple[bool, str, "SimplifiedAst"]]


def _simplify_ast(raw_ast: ParseResults) -> SimplifiedAst:
    """Simplify an AST that comes out of the parser

    As well as replacing pyparsing's ParseResults with bare lists, this merges
    adjacent non-condition words. For example, "a b" parses to ["a", "b"]. This
    function merges that to ["a b"].

    The idea is that this will be much more efficient to match against tags for
    the vast majority of ASTs, which have many more raw words than they have
    conditions.

    A simplified AST is a list whose items are strings (representing bare
    words) or tuples of the form (negated, flag, ast), where negated is a bool,
    flag is a string and ast is another simplified ast.

    """
    children: SimplifiedAst = []
    str_acc = []
    for expr in raw_ast:
        if isinstance(expr, str):
            str_acc.append(expr)
            continue

        # We have a term that isn't a string. This must be a conditional. Join
        # together any items in str_acc and add them to children then recurse
        # to simplify the conditional's sub-expression.
        if str_acc:
            children.append(" ".join(str_acc))
            str_acc = []

        negated, flag, exprs = expr
        assert isinstance(negated, bool)
        assert isinstance(flag, str)
        children.append((negated, flag, _simplify_ast(exprs)))

    if str_acc:
        children.append(" ".join(str_acc))

    return children


@lru_cache(maxsize=2048)
def parse(string: str) -> SimplifiedAst:
    """Parse a string to a simplified AST.

    Raises a ValueError if the string is malformed in some way.

    """
    try:
        raw_ast = _get_parser().parse_string(string, parse_all=True)
    except ParseException as err:
        raise ValueError(
            f"Invalid syntax for string: {err}. Parsed text was {string!r}."
        ) from None

    return _simplify_ast(raw_ast)


def expand(ast: SimplifiedAst, flag_defs: FlagDefs) -> Sequence[str]:
    """Expand ast for the given flag_defs.

    Returns a (possibly empty) list of strings

    """
    expanded: list[str] = []
    for child in ast:
        if isinstance(child, str):
            expanded.append(child)
            continue

        # We have a conditional expression. Is the condition true? If not,
        # skip it.
        negated, flag, exprs = child
        if (flag in flag_defs) == negated:
            # The condition was false
            continue

        # The condition was true
        expanded += expand(exprs, flag_defs)
    return expanded


class Expr(str):
    """A CAPI2 string that may contain `?`-conditional expressions."""

    __slots__ = ()

    @validate_call
    def expand(self, flag_defs: FlagDefs) -> str:
        ast = parse(self)

        # An extra optimisation for the common case where the whole ast boils
        # down to a single string with no conditions.
        if len(ast) == 1 and isinstance(ast[0], str):
            return ast[0]

        return " ".join(expand(ast, flag_defs))

    @classmethod
    def __get_pydantic_core_schema__(
        cls, _source_type: Any, _handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        return core_schema.no_info_after_validator_function(
            cls,
            core_schema.str_schema(),
        )
